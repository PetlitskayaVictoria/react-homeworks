import React from "react";

function AlternativeSuperInputText() {
    return (
        <input/>
    );
}

export default AlternativeSuperInputText;
